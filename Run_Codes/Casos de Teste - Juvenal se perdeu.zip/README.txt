Arquivo zip gerado em: 27/07/2017 22:09:01 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Juvenal se perdeu